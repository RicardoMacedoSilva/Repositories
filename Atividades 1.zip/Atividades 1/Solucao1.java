public class Solucao1g {
    public static void main(String[] args) {
        String palavra1 = "primeira";
        String palavra2 = "segunda";
        String palavra3 = "terceira";

        System.out.println(palavra1 + " " + palavra2 + " " + palavra3);
    }
}
