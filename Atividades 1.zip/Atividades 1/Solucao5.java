public class Solucao5 {
    public static void main(String[] args) {
        char c1 = 'H';
        char c2 = 'e';
        char c3 = 'l';
        char c4 = 'l';
        char c5 = 'o';
        char c6 = ' ';
        char c7 = 'W';
        char c8 = 'o';
        char c9 = 'r';
        char c10 = 'l';
        char c11 = 'd';

        System.out.println("" + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11);
    }
}
