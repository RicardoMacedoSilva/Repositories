public class Solucao3 {
    public static void main(String[] args) {
        int dia = 14;
        int mes = 10;
        int ano = 2024;

        System.out.println(dia + "/" + mes + "/" + ano);
    }
}
