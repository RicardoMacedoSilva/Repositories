public class Solucao6 {
    public static void main(String[] args) {
        char milhar = '1';
        char centena = '2';
        char dezena = '3';
        char unidade = '4';

        String numeroCompleto = "" + milhar + centena + dezena + unidade;

        System.out.println(numeroCompleto);
    }
}
