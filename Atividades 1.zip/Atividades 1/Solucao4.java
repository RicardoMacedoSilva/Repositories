public class Solucao4 {
    public static void main(String[] args) {
        double peso = 72.5;

        System.out.println("O peso informado foi " + peso + " kg.");
    }
}
