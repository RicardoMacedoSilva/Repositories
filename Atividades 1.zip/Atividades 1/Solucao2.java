public class Solucao2 {
    public static void main(String[] args) {
        int numero = 42;

        System.out.println("O valor do número digitado é: " + numero);
    }
}

