import javax.swing.JOptionPane;

public class Solucao5 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número: ");
        int numero = Integer.parseInt(sNumero);
        
           if (numero >= 20 && numero <= 90) {
               System.out.println("O número está entre 20 e 90.");
           } else {
               System.out.println("O número não está entre 20 e 90.");
        }
    }
}
