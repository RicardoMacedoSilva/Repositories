import javax.swing.JOptionPane;

public class Solucao13 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número inteiro de 3 dígitos: ");
        int numero = Integer.parseInt(sNumero);
        
        int dezenas = (numero / 10) % 10;
        
        if (dezenas % 2 == 0) {
            System.out.println("O algarismo da casa das dezenas é par.");
        } else {
            System.out.println("O algarismo da casa das dezenas é ímpar.");
        }
    }
}
