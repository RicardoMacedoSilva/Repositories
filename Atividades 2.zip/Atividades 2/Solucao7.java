import javax.swing.JOptionPane;

public class Solucao7 {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite seu nome: ");
        String sSexo = JOptionPane.showInputDialog("Digite seu sexo (f ou m): ");
        String sIdade = JOptionPane.showInputDialog("Digite sua idade: ");
        
        char sexo = sSexo.charAt(0);
        int idade = Integer.parseInt(sIdade);
        
        if ((sexo == 'f' || sexo == 'F') && idade < 25) {
            System.out.println(nome + ": ACEITA");
        } else {
            System.out.println(nome + ": NÃO ACEITA");
        }
    }
}
