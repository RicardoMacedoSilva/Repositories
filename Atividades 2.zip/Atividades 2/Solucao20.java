import javax.swing.JOptionPane;

public class Solucao20 {
    public static void main(String[] args) {
        String sNumero1 = JOptionPane.showInputDialog("Digite o primeiro número: ");
        String sNumero2 = JOptionPane.showInputDialog("Digite o segundo número: ");
        
        int numero1 = Integer.parseInt(sNumero1);
        int numero2 = Integer.parseInt(sNumero2);
        
        if (numero1 < numero2) {
            System.out.println("O quadrado do menor número (" + numero1 + ") é: " + (numero1 * numero1));
            System.out.println("A raiz quadrada do maior número (" + numero2 + ") é: " + Math.sqrt(numero2));
        } else {
            System.out.println("O quadrado do menor número (" + numero2 + ") é: " + (numero2 * numero2));
            System.out.println("A raiz quadrada do maior número (" + numero1 + ") é: " + Math.sqrt(numero1));
        }
    }
}
