import javax.swing.JOptionPane;

public class Solucao18 {
    public static void main(String[] args) {
        String sNumero1 = JOptionPane.showInputDialog("Digite o primeiro número: ");
        String sNumero2 = JOptionPane.showInputDialog("Digite o segundo número: ");
        
        int numero1 = Integer.parseInt(sNumero1);
        int numero2 = Integer.parseInt(sNumero2);
        
        if (numero1 < numero2) {
            System.out.println("Os números em ordem crescente são: " + numero1 + ", " + numero2);
        } else {
            System.out.println("Os números em ordem crescente são: " + numero2 + ", " + numero1);
        }
    }
}
