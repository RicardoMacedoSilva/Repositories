import javax.swing.JOptionPane;

public class Solucao11 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número: ");
        int numero = Integer.parseInt(sNumero);
        
        if (numero % 3 == 0 && numero % 7 == 0) {
            System.out.println("O número é divisível por 3 e por 7.");
        } else {
            System.out.println("O número não é divisível 
