import javax.swing.JOptionPane;

public class Solucao3 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número: ");
        
        double numero = Double.parseDouble(sNumero);
        
        if (numero >= 0) {
            System.out.println("A raiz quadrada é: " + Math.sqrt(numero));
        } else {
            System.out.println("O quadrado do número é: " + (numero * numero));
        }
    }
}
