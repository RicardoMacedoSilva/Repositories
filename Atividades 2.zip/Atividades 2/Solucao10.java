import javax.swing.JOptionPane;

public class Solucao10 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número: ");
        int numero = Integer.parseInt(sNumero);
        
        if (numero % 5 == 0) {
            System.out.println("O número é divisível por 5.");
        } else {
            System.out.println("O número não é divisível por 5.");
        
