import javax.swing.JOptionPane;

public class Solucao2 {
    public static void main(String[] args) {
        String sNumero1 = JOptionPane.showInputDialog("Digite o primeiro número: ");
        String sNumero2 = JOptionPane.showInputDialog("Digite o segundo número: ");
        
        int numero1 = Integer.parseInt(sNumero1);
        int numero2 = Integer.parseInt(sNumero2);
        
        int soma = numero1 + numero2;

        if (soma <= 20) {
            soma -= 5;
        }

        System.out.println("O resultado é: " + soma);
    }
}
