import javax.swing.JOptionPane;

public class Solucao15 {
    public static void main(String[] args) {
        String sAnoNascimento = JOptionPane.showInputDialog("Digite o ano de nascimento: ");
        String sAnoAtual = JOptionPane.showInputDialog("Digite o ano atual: ");
        
        int anoNascimento = Integer.parseInt(sAnoNascimento);
        int anoAtual = Integer.parseInt(sAnoAtual);
        
        if (anoNascimento > 0 && anoAtual >= anoNascimento) {
            int idade = anoAtual - anoNascimento;
            System.out.println("A idade da pessoa é: " + idade + " anos.");
        } else {
            System.out.println("Ano de nascimento inválido.");
        }
    }
}
   