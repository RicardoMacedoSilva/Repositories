import javax.swing.JOptionPane;

public class Solucao1 {
    public static void main(String[] args) {
        String sValor1 = JOptionPane.showInputDialog("Digite o primeiro valor inteiro: ");
        String sValor2 = JOptionPane.showInputDialog("Digite o segundo valor inteiro: ");
        
        int valor1 = Integer.parseInt(sValor1);
        int valor2 = Integer.parseInt(sValor2);
        
        int soma = valor1 + valor2;

        if (soma > 10) {
            System.out.println("A soma dos valores é: " + soma);
        }
    }
}
