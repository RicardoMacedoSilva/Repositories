import javax.swing.JOptionPane;

public class Solucao23 {
    public static void main(String[] args) {
        String sNumero1 = JOptionPane.showInputDialog("Digite o primeiro número: ");
        String sNumero2 = JOptionPane.showInputDialog("Digite o segundo número: ");
        String sNumero3 = JOptionPane.showInputDialog("Digite o terceiro número: ");
        
        int numero1 = Integer.parseInt(sNumero1);
        int numero2 = Integer.parseInt(sNumero2);
        int numero3 = Integer.parseInt(sNumero3);
        
        int maior = numero1;
        int menor = numero1;

        if (numero2 > maior) {
            maior = numero2;
        }
        if (numero3 > maior) {
            maior = numero3;
        }
        if (numero2 < menor) {
            menor = numero2;
        }
        if (numero3 < menor) {
            menor = numero3;
        }

        int intermediario = numero1 + numero2 + numero3 - maior - menor;

        System.out.println("Maior: " + maior);
        System.out.println("Intermediário: " + intermediario);
        System.out.println("Menor: " + menor);
    }
}
