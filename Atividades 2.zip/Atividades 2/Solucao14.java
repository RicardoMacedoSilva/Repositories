import javax.swing.JOptionPane;

public class Solucao14 {
    public static void main(String[] args) {
        String sNumero = JOptionPane.showInputDialog("Digite um número inteiro de 4 dígitos: ");
        int numero = Integer.parseInt(sNumero);
        
        int milhar = (numero / 1000) % 10;
        int centena = (numero / 100) % 10;
        
        int formado = milhar * 10 + centena;

        if (formado % 4 == 0) {
            System.out.println("O número formado por " + milhar + " e " + centena + " é múltiplo de 4.");
        } else {
            System.out.println("O número formado por " + milhar + " e " + centena + " não é múltiplo de 4.");
        }
    }
}
